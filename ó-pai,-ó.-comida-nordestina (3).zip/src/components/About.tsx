/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Leaf, Award, Users, Heart, Star } from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: <Users className="w-5 h-5 text-[#FF7A00]" />,
      title: 'Ambiente Familiar',
      description: 'Um espaço aconchegante e amigável, ideal para reunir a família e os amigos para almoços festivos ou jantares memoráveis.',
    },
    {
      icon: <Leaf className="w-5 h-5 text-[#2E7D32]" />,
      title: 'Ingredientes de Origem',
      description: 'Trabalhamos apenas com insumos selecionados, trazendo a autêntica farinha de mandioca, queijos coalho e manteigas de garrafa diretamente do Nordeste.',
    },
    {
      icon: <Award className="w-5 h-5 text-[#FFC107]" />,
      title: 'Tradição Culinária',
      description: 'Nossas receitas são patrimônios familiares passados de geração em geração, cozinhadas com paciência, amor e fogo brando.',
    },
    {
      icon: <Heart className="w-6 h-6 text-[#FF7A00]" />,
      title: 'Atendimento Acolhedor',
      description: 'O calor humano e o sorriso aberto da nossa equipe são nosso selo de qualidade. Aqui, todo cliente vira parte da casa.',
    },
  ];

  return (
    <section id="sobre" className="py-20 sm:py-28 bg-[#FDFCF9] overflow-hidden border-b border-black/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Visual Showcase Block */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-5 relative"
          >
            {/* Background earthy geometric accent */}
            <div className="absolute -top-6 -left-6 w-32 h-32 border border-[#FFC107]/20 rounded-none -z-10 animate-pulse" />
            <div className="absolute -bottom-6 -right-6 w-44 h-44 border border-[#FF7A00]/10 rounded-none -z-10" />

            {/* Main Image */}
            <div className="relative rounded-none overflow-hidden border border-black/10 bg-white p-2 shadow-none">
              <img
                src="/src/assets/images/ambient_turf_garden_1782402161783.jpg"
                alt="Ambiente Ó Pai Ó Comida Nordestina"
                loading="lazy"
                className="w-full h-[450px] object-cover hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              {/* Overlay with info */}
              <div className="absolute bottom-2 left-2 right-2 bg-[#1A1A1A]/90 p-6 text-white border border-white/10">
                <p className="font-serif text-lg italic text-nordeste-yellow">"Um oásis verde no meio de São Paulo."</p>
                <div className="flex items-center space-x-1 mt-2">
                  <Star className="w-4 h-4 text-nordeste-yellow fill-nordeste-yellow" />
                  <Star className="w-4 h-4 text-nordeste-yellow fill-nordeste-yellow" />
                  <Star className="w-4 h-4 text-nordeste-yellow fill-nordeste-yellow" />
                  <Star className="w-4 h-4 text-nordeste-yellow fill-nordeste-yellow" />
                  <Star className="w-4 h-4 text-nordeste-yellow fill-nordeste-yellow" />
                  <span className="text-[10px] uppercase tracking-wider text-gray-400 ml-2">(4.7 / 5 Google)</span>
                </div>
              </div>
            </div>

            {/* Small floating badge */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="absolute -bottom-4 -left-4 bg-[#FF7A00] text-white p-4 rounded-none border border-black/10 flex flex-col items-center justify-center text-center w-28 h-28"
            >
              <span className="font-serif text-3xl font-bold text-white">100%</span>
              <span className="text-[9px] uppercase font-bold tracking-widest font-sans leading-tight text-white/90">Autêntico Sertão</span>
            </motion.div>
          </motion.div>

          {/* Text Content Block */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-7 flex flex-col"
          >
            <span className="text-xs font-sans font-bold tracking-[0.2em] text-[#FF7A00] uppercase mb-3">Nossa História</span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold tracking-tight text-[#1A1A1A] mb-6 leading-tight">
              O Sertão na Capital Paulista
            </h2>
            
            <div className="prose prose-lg text-gray-600 font-sans space-y-4 mb-8 leading-relaxed">
              <p>
                O restaurante <strong className="text-nordeste-green font-bold">Ó Pai, ó. Comida Nordestina</strong> nasceu com o propósito de aproximar os paulistanos e a comunidade de conterrâneos do verdadeiro espírito da culinária nordestina. Comandado por uma equipe apaixonada pela hospitalidade do Nordeste, estabelecemos nossa casa em São Paulo, transformando cada refeição em uma celebração da nossa rica cultura.
              </p>
              <p>
                Aqui, preparamos pratos emblemáticos com o máximo respeito pelas tradições originais. Da escolha cuidadosa do feijão-de-corda ao cozimento em fogo brando das costelas, cada etapa é feita de forma caseira. Nossa famosa área verde foi projetada para ser um oásis de serenidade e ar puro no bairro da Vila Prel — o ambiente ideal para almoços familiares demorados e regados a boa música.
              </p>
            </div>

            {/* Key Pillars Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {values.map((val, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1, duration: 0.5 }}
                  className="flex space-x-4 p-5 rounded-none bg-white border border-black/5 shadow-none hover:border-black/15 transition-all duration-300"
                >
                  <div className="flex-shrink-0 p-3 rounded-none bg-[#FDFCF9] h-fit border border-black/5">
                    {val.icon}
                  </div>
                  <div>
                    <h4 className="text-sm font-sans font-bold tracking-wider uppercase text-[#1A1A1A] mb-1">{val.title}</h4>
                    <p className="text-xs text-gray-500 leading-relaxed">{val.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

          </motion.div>

        </div>
      </div>
    </section>
  );
}
