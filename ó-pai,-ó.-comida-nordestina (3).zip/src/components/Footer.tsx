/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Heart, MessageCircle } from 'lucide-react';
import { contactInfo } from '../data';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenAdmin: () => void;
}

export default function Footer({ onNavigate, onOpenAdmin }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { id: 'inicio', label: 'Início' },
    { id: 'sobre', label: 'Sobre Nós' },
    { id: 'cardapio', label: 'Cardápio' },
    { id: 'galeria', label: 'Galeria' },
    { id: 'avaliacoes', label: 'Avaliações' },
    { id: 'reservas', label: 'Reservas' },
    { id: 'localizacao', label: 'Localização' },
  ];

  return (
    <footer id="footer" className="bg-[#1A1A1A] text-white pt-16 pb-8 border-t border-white/10 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          
          {/* Brand Presentation Column */}
          <div className="md:col-span-4 flex flex-col space-y-4">
            <div onClick={() => onNavigate('inicio')} className="cursor-pointer">
              <span className="font-serif text-3xl font-bold text-white tracking-tight">Ó Pai, ó.</span>
              <p className="text-[10px] uppercase font-sans tracking-[0.25em] font-bold text-[#FF7A00] -mt-1">
                Comida Nordestina
              </p>
            </div>
            <p className="text-gray-400 font-sans text-xs font-light leading-relaxed max-w-sm">
              Trazendo a autenticidade culinária e o aconchego do sertão nordestino direto para a Vila Prel, em São Paulo. Ingredientes de origem e sabor inigualável.
            </p>

            {/* High-conversion WhatsApp CTA inside footer */}
            <div className="pt-1">
              <a
                href={`https://wa.me/${contactInfo.whatsapp}?text=Ol%C3%A1%21+Gostaria+de+fazer+um+pedido+no+%C3%93+Pai%2C+%C3%B3.+Comida+Nordestina.`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-nordeste-green hover:bg-[#34D399] text-white font-bold text-xs uppercase tracking-wider transition-all shadow hover:shadow-green-500/10 rounded-none"
              >
                <MessageCircle className="w-4 h-4 text-white animate-bounce" />
                Pedir no WhatsApp
              </a>
            </div>
            
            {/* Social Media */}
            <div className="flex items-center space-x-3 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="p-2.5 bg-white/5 hover:bg-[#FF7A00] border border-white/10 rounded-none transition-all text-gray-300 hover:text-white"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="p-2.5 bg-white/5 hover:bg-[#FF7A00] border border-white/10 rounded-none transition-all text-gray-300 hover:text-white"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links Column */}
          <div className="md:col-span-2 flex flex-col space-y-4">
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-[#FF7A00]">Navegação</h4>
            <ul className="space-y-2.5 text-xs font-sans font-light text-gray-400">
              {quickLinks.slice(0, 4).map((link) => (
                <li key={`footer-nav-col1-${link.id}`}>
                  <button
                    onClick={() => onNavigate(link.id)}
                    className="hover:text-nordeste-yellow transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2 flex flex-col space-y-4">
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-[#FF7A00] opacity-0 md:opacity-100 select-none">Navegação 2</h4>
            <ul className="space-y-2.5 text-xs font-sans font-light text-gray-400">
              {quickLinks.slice(4).map((link) => (
                <li key={`footer-nav-col2-${link.id}`}>
                  <button
                    onClick={() => onNavigate(link.id)}
                    className="hover:text-nordeste-yellow transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Opening hours Column */}
          <div className="md:col-span-4 flex flex-col space-y-4">
            <h4 className="font-sans font-bold text-xs uppercase tracking-widest text-[#FF7A00]">Funcionamento</h4>
            
            <div className="space-y-3.5 text-xs font-sans">
              <div className="flex gap-2.5 text-gray-400">
                <Clock className="w-3.5 h-3.5 text-[#FFC107] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white uppercase tracking-wider">Terça a Sexta-feira</p>
                  <p className="text-xs text-gray-400 font-light mt-0.5">11h30 às 22h00</p>
                </div>
              </div>

              <div className="flex gap-2.5 text-gray-400">
                <Clock className="w-3.5 h-3.5 text-[#FFC107] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white uppercase tracking-wider">Sábados, Domingos e Feriados</p>
                  <p className="text-xs text-gray-400 font-light mt-0.5">11h30 às 23h00</p>
                </div>
              </div>

              <div className="flex gap-2.5 text-gray-400">
                <MapPin className="w-3.5 h-3.5 text-[#FF7A00] flex-shrink-0 mt-0.5" />
                <span className="text-xs leading-relaxed font-light">
                  {contactInfo.address.street}, {contactInfo.address.number} — {contactInfo.address.neighborhood}, São Paulo - SP
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Footer Bottom Row */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-sans text-gray-500">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 sm:gap-3">
            <p>© {currentYear} Ó Pai, ó. Comida Nordestina. Todos os direitos reservados.</p>
            <span className="hidden sm:inline text-gray-700">•</span>
            <button 
              onClick={onOpenAdmin}
              className="hover:text-[#FF7A00] transition-colors font-semibold cursor-pointer underline decoration-dotted"
            >
              Área Administrativa
            </button>
          </div>
          <div className="flex items-center gap-1">
            <span>Desenvolvido com</span>
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" />
            <span>para São Paulo</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
