/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Phone, Utensils, Star, MapPin } from 'lucide-react';
import { contactInfo } from '../data';

interface HeroProps {
  onNavigate: (sectionId: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  const whatsappUrl = `https://wa.me/${contactInfo.whatsapp}?text=Ol%C3%A1%21+Gostaria+de+fazer+um+pedido+ou+saber+mais+sobre+o+card%C3%A1pio.`;

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center bg-nordeste-dark overflow-hidden pt-16"
    >
      {/* Background Image with Parallax & Ken Burns effect */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <motion.img
          initial={{ scale: 1.15, opacity: 0 }}
          animate={{ scale: 1.02, opacity: 0.65 }}
          transition={{ duration: 12, ease: 'easeOut' }}
          src="/src/assets/images/opaio_hero_banner_1782400708182.jpg"
          alt="Comida Nordestina Ó Pai Ó"
          className="w-full h-full object-cover object-center filter brightness-50 contrast-110"
          referrerPolicy="no-referrer"
        />
        {/* Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-nordeste-cream via-nordeste-dark/50 to-nordeste-dark/70 z-10 mix-blend-multiply" />
        <div className="absolute inset-0 bg-gradient-to-r from-nordeste-dark/90 via-transparent to-nordeste-dark/80 z-10" />
      </div>

      {/* Decorative Traditional Lace (Rendando) / Cordel Style Overlay */}
      <div className="absolute bottom-0 left-0 w-full h-16 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-nordeste-cream via-transparent to-transparent opacity-40 z-20" />

      {/* Hero Content */}
      <div className="relative z-30 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white py-12 md:py-24">
        {/* Award/Badge Info */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="inline-flex items-center space-x-2 bg-[#FF7A00]/10 border border-[#FF7A00]/30 px-5 py-2 rounded-none mb-6 sm:mb-8"
        >
          <Star className="w-4 h-4 text-nordeste-yellow fill-nordeste-yellow" />
          <span className="text-xs font-sans font-bold tracking-widest text-[#FFFDF9] uppercase">
            ★ 4.7/5 no Google — O Verdadeiro Sabor
          </span>
        </motion.div>

        {/* Main Title */}
        <motion.h1
          initial={{ opacity: 0, y: 35 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif font-bold tracking-tight leading-[1.1] mb-6 max-w-4xl mx-auto"
        >
          O Verdadeiro <span className="text-[#FF7A00] italic font-normal">Sabor</span> do <br />
          <span className="font-serif font-black text-nordeste-yellow">
            Nordeste em São Paulo
          </span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.6 }}
          className="text-base sm:text-lg md:text-xl text-gray-200 font-sans font-light max-w-2xl mx-auto mb-10 sm:mb-12 leading-relaxed"
        >
          Comida caseira sertaneja, ambiente acolhedor e receitas tradicionais que conquistam todos os paladares paulistanos. Venha nos visitar ou peça em casa!
        </motion.p>

        {/* Buttons Action */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-6"
        >
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noreferrer"
            className="w-full sm:w-auto flex items-center justify-center space-x-3 bg-nordeste-green hover:bg-[#FF7A00] text-white font-sans font-bold text-xs uppercase tracking-widest px-8 py-4 rounded-none transition-all duration-300 group"
          >
            <Phone className="w-4 h-4 text-white" />
            <span>Pedir pelo WhatsApp</span>
          </a>

          <button
            onClick={() => onNavigate('cardapio')}
            className="w-full sm:w-auto flex items-center justify-center space-x-3 bg-transparent hover:bg-white/10 text-white font-sans font-bold text-xs uppercase tracking-widest px-8 py-4 rounded-none transition-all duration-300 border border-white/50 hover:border-white"
          >
            <Utensils className="w-4 h-4 text-nordeste-yellow" />
            <span>Ver Nosso Cardápio</span>
          </button>
        </motion.div>

        {/* Quick Highlights Row */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 max-w-3xl mx-auto mt-16 sm:mt-24 pt-8 border-t border-white/10"
        >
          <div className="flex items-center justify-center sm:justify-start space-x-3 text-left">
            <div className="p-2.5 rounded-none bg-[#FF7A00]/10 text-[#FF7A00] border border-[#FF7A00]/20">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-sans">Localização</p>
              <p className="text-sm font-medium text-white font-sans">{contactInfo.address.neighborhood}, SP</p>
            </div>
          </div>

          <div className="flex items-center justify-center sm:justify-start space-x-3 text-left">
            <div className="p-2.5 rounded-none bg-nordeste-yellow/10 text-nordeste-yellow border border-nordeste-yellow/20">
              <Utensils className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-sans">Culinária</p>
              <p className="text-sm font-medium text-white font-sans">100% Nordestina Autêntica</p>
            </div>
          </div>

          <div className="flex items-center justify-center sm:justify-start space-x-3 text-left">
            <div className="p-2.5 rounded-none bg-nordeste-green/10 text-nordeste-green-light border border-nordeste-green-light/20">
              <Star className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest font-sans">Ambiente</p>
              <p className="text-sm font-medium text-white font-sans">Área Verde & Espaço Familiar</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
