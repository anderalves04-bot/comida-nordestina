/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Phone, Clock, Calendar, Lock } from 'lucide-react';
import { contactInfo } from '../data';

interface NavbarProps {
  onNavigate: (sectionId: string) => void;
  activeSection: string;
  onOpenAdmin: () => void;
}

export default function Navbar({ onNavigate, activeSection, onOpenAdmin }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isOpenNow, setIsOpenNow] = useState(false);

  // Check if restaurant is currently open
  useEffect(() => {
    const checkOpenStatus = () => {
      const now = new Date();
      const day = now.getDay(); // 0: Sunday, 1: Monday, ..., 6: Saturday
      const hours = now.getHours();
      const minutes = now.getMinutes();
      const currentTimeInMins = hours * 60 + minutes;

      const openTimeInMins = 11 * 60 + 30; // 11:30

      if (day === 1) {
        // Segunda-feira fechado
        setIsOpenNow(false);
        return;
      }

      let closeTimeInMins = 22 * 60; // 22:00 (Ter-Sex)
      if (day === 0 || day === 6) {
        closeTimeInMins = 23 * 60; // 23:00 (Sáb-Dom)
      }

      if (currentTimeInMins >= openTimeInMins && currentTimeInMins < closeTimeInMins) {
        setIsOpenNow(true);
      } else {
        setIsOpenNow(false);
      }
    };

    checkOpenStatus();
    const interval = setInterval(checkOpenStatus, 60000); // Check every minute
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'inicio', label: 'Início' },
    { id: 'sobre', label: 'Sobre Nós' },
    { id: 'cardapio', label: 'Cardápio' },
    { id: 'galeria', label: 'Galeria' },
    { id: 'avaliacoes', label: 'Avaliações' },
    { id: 'reservas', label: 'Reservas' },
    { id: 'localizacao', label: 'Localização' },
  ];

  const handleLinkClick = (id: string) => {
    setIsOpen(false);
    onNavigate(id);
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-nordeste-cream/95 backdrop-blur-md py-4 border-b border-black/5 shadow-none text-[#1A1A1A]'
          : 'bg-gradient-to-b from-[#1A1A1A]/80 to-transparent py-5 text-white'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <div
            onClick={() => handleLinkClick('inicio')}
            className="flex flex-col cursor-pointer select-none group"
          >
            <span
              className={`font-serif text-2xl sm:text-3xl font-bold tracking-tight transition-colors duration-300 ${
                isScrolled ? 'text-nordeste-green' : 'text-nordeste-yellow'
              } group-hover:text-[#FF7A00]`}
            >
              Ó Pai, ó.
            </span>
            <span
              className={`text-[9px] uppercase tracking-[0.25em] font-sans font-semibold transition-colors duration-300 ${
                isScrolled ? 'text-[#FF7A00]' : 'text-gray-200'
              }`}
            >
              Comida Nordestina
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-2">
            {navLinks.map((link) => (
              <button
                key={`desktop-nav-${link.id}`}
                onClick={() => handleLinkClick(link.id)}
                className={`px-3 py-2 text-xs uppercase tracking-widest font-semibold transition-all duration-200 relative ${
                  activeSection === link.id
                    ? isScrolled
                      ? 'text-[#FF7A00] font-bold'
                      : 'text-nordeste-yellow font-bold'
                    : isScrolled
                    ? 'text-gray-700 hover:text-[#FF7A00]'
                    : 'text-gray-150 hover:text-nordeste-yellow'
                }`}
              >
                {link.label}
                {activeSection === link.id && (
                  <motion.div
                    layoutId="activeIndicator"
                    className={`absolute bottom-0 left-3 right-3 h-[2px] ${
                      isScrolled ? 'bg-[#FF7A00]' : 'bg-nordeste-yellow'
                    }`}
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Opening Status and Booking Button */}
          <div className="hidden sm:flex items-center space-x-4">
            {/* Live Status Indicator */}
            <div className={`flex items-center space-x-2 px-3 py-1.5 rounded-none border ${
              isScrolled ? 'bg-white/50 border-black/5 text-[#1A1A1A]' : 'bg-black/20 border-white/10 text-white'
            }`}>
              <span className={`relative flex h-2 w-2`}>
                <span
                  className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    isOpenNow ? 'bg-nordeste-green' : 'bg-red-500'
                  }`}
                ></span>
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    isOpenNow ? 'bg-nordeste-green' : 'bg-red-500'
                  }`}
                ></span>
              </span>
              <span className="text-[10px] font-sans font-bold tracking-widest uppercase">
                {isOpenNow ? 'Aberto até as 22h' : 'Fechado'}
              </span>
            </div>

            {/* Quick Reservation Button */}
            <button
              onClick={() => handleLinkClick('reservas')}
              className={`flex items-center space-x-2 text-xs uppercase tracking-widest font-sans font-bold px-5 py-2.5 rounded-none transition-all duration-300 shadow-none border ${
                isScrolled
                  ? 'bg-nordeste-green border-nordeste-green text-white hover:bg-[#FF7A00] hover:border-[#FF7A00]'
                  : 'bg-white text-[#1A1A1A] border-white hover:bg-nordeste-yellow'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Reservar Mesa</span>
            </button>

            {/* Admin Key Button */}
            <button
              onClick={onOpenAdmin}
              className={`p-2.5 rounded-none border transition-all duration-300 ${
                isScrolled
                  ? 'bg-transparent border-black/10 text-gray-700 hover:text-nordeste-orange hover:border-nordeste-orange'
                  : 'bg-black/20 border-white/10 text-white hover:text-nordeste-yellow hover:border-nordeste-yellow'
              }`}
              title="Painel do Administrador"
              aria-label="Painel Administrativo"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="flex lg:hidden items-center space-x-2">
            {/* Live Status Indicator for Mobile */}
            <div className="flex items-center space-x-1.5 px-2 py-1 rounded-full border border-current/15 text-[10px]">
              <span className={`relative flex h-2 w-2`}>
                <span
                  className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    isOpenNow ? 'bg-nordeste-green' : 'bg-red-500'
                  }`}
                ></span>
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    isOpenNow ? 'bg-nordeste-green' : 'bg-red-500'
                  }`}
                ></span>
              </span>
              <span
                className={`font-display font-medium ${
                  isScrolled
                    ? isOpenNow
                      ? 'text-nordeste-green'
                      : 'text-red-600'
                    : 'text-white'
                }`}
              >
                {isOpenNow ? 'ABERTO' : 'FECHADO'}
              </span>
            </div>

            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`p-2 rounded-md focus:outline-none transition-colors ${
                isScrolled ? 'text-gray-800 hover:bg-black/5' : 'text-white hover:bg-white/10'
              }`}
              aria-label="Menu principal"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="lg:hidden bg-nordeste-cream border-b border-nordeste-orange/10 overflow-hidden shadow-xl"
          >
            <div className="px-4 pt-2 pb-6 space-y-1 sm:px-6">
              {navLinks.map((link) => (
                <button
                  key={`mobile-nav-${link.id}`}
                  onClick={() => handleLinkClick(link.id)}
                  className={`block w-full text-left px-4 py-3 rounded-lg text-base font-medium transition-colors ${
                    activeSection === link.id
                      ? 'bg-nordeste-orange/10 text-nordeste-orange font-semibold'
                      : 'text-gray-700 hover:bg-black/5 hover:text-nordeste-orange'
                  }`}
                >
                  {link.label}
                </button>
              ))}

              <div className="pt-4 border-t border-gray-200/50 mt-4 flex flex-col gap-3">
                <button
                  onClick={() => handleLinkClick('reservas')}
                  className="w-full flex items-center justify-center space-x-2 bg-nordeste-orange hover:bg-nordeste-terracotta text-white font-display font-bold py-3 rounded-lg shadow transition-colors"
                >
                  <Calendar className="w-4 h-4" />
                  <span>RESERVAR MESA</span>
                </button>

                <a
                  href={`https://wa.me/${contactInfo.whatsapp}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full flex items-center justify-center space-x-2 bg-nordeste-green hover:bg-nordeste-green/90 text-white font-display font-bold py-3 rounded-lg shadow transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  <span>PEDIR PELO WHATSAPP</span>
                </a>

                <button
                  onClick={() => {
                    setIsOpen(false);
                    onOpenAdmin();
                  }}
                  className="w-full flex items-center justify-center space-x-2 border border-nordeste-orange/30 text-nordeste-orange hover:bg-nordeste-orange/5 font-display font-bold py-3 rounded-lg transition-colors"
                >
                  <Lock className="w-4 h-4" />
                  <span>PAINEL ADMINISTRATIVO</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
