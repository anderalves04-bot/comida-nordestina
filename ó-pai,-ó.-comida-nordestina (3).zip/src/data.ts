/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Dish, Review, ContactInfo } from './types';

export const contactInfo: ContactInfo = {
  phone: '(11) 99412-3920',
  whatsapp: '5511994123920',
  whatsappFormatted: '(11) 99412-3920',
  email: 'contato@opaio.com.br',
  address: {
    street: 'Rua Thereza Maia Pinto',
    number: '186',
    neighborhood: 'Vila Prel',
    city: 'São Paulo',
    state: 'SP',
    zipCode: '05780-390'
  },
  openingHours: {
    weekday: 'Terça a Sexta: 11h30 às 22h',
    weekend: 'Sábados, Domingos e Feriados: 11h30 às 23h'
  }
};

export const dishes: Dish[] = [
  {
    id: 'baiao',
    name: 'Baião de Dois',
    description: 'Arroz cozido com feijão-de-corda, carne-seca desfiada, bacon crocante, calabresa de primeira, queijo coalho grelhado derretido e um toque final de manteiga de garrafa e coentro fresco.',
    price: 68.00,
    category: 'principais',
    image: '/src/assets/images/opaio_baiao_de_dois_1782400719225.jpg',
    tags: ['Especialidade', 'Mais Pedido', 'Serve 2 Pessoas'],
    isHighlight: true
  },
  {
    id: 'carne_sol',
    name: 'Carne de Sol de Caicó',
    description: 'Nossa autêntica carne de sol grelhada na chapa com bastante manteiga de garrafa, coberta com finas rodelas de cebola roxa caramelizada. Acompanha macaxeira frita bem crocante e vinagrete da casa.',
    price: 74.00,
    category: 'principais',
    image: '/src/assets/images/opaio_carne_de_sol_1782400751509.jpg',
    tags: ['Tradicional', 'Grelhado', 'Serve 2 Pessoas'],
    isHighlight: true
  },
  {
    id: 'escondidinho',
    name: 'Escondidinho de Carne Seca',
    description: 'Delicioso purê de macaxeira (mandioca) cremoso, feito com creme de leite fresco e queijo, recheado com carne-seca bem desfiada e temperada, gratinado com queijo coalho e queijo minas.',
    price: 48.00,
    category: 'principais',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600',
    tags: ['Cremoso', 'Gratinado', 'Individual'],
    isHighlight: true
  },
  {
    id: 'feijoada',
    name: 'Feijoada Delícia',
    description: 'Feijoada encorpada com cortes selecionados de carne seca, lombo, costelinha suína e paio de qualidade. Acompanha couve refogada no alho, torresmo pururuca super crocante, farofa artesanal, laranja e arroz branco.',
    price: 42.00,
    category: 'principais',
    image: 'https://images.unsplash.com/photo-1541518763669-27fef04b14ea?auto=format&fit=crop&q=80&w=600',
    tags: ['Favorito', 'Completo', 'Fim de Semana'],
    isHighlight: true
  },
  {
    id: 'costela',
    name: 'Costela Nordestina ao Forno',
    description: 'Costela bovina cozida lentamente no vapor com temperos nordestinos até desmanchar, finalizada no forno a lenha. Acompanha purê de jerimum (abóbora), farofa de cuscuz e salada de agrião.',
    price: 79.00,
    category: 'principais',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600',
    tags: ['Lento no Forno', 'Sucesso', 'Serve 2 Pessoas'],
    isHighlight: true
  },
  {
    id: 'cartola',
    name: 'Cartola de Pernambuco',
    description: 'A clássica sobremesa pernambucana: bananas grelhadas na manteiga de garrafa, cobertas com generosa camada de queijo coalho derretido e polvilhadas com açúcar e canela em pó.',
    price: 22.00,
    category: 'sobremesas',
    image: 'https://images.unsplash.com/photo-1551024601-bec78aea704b?auto=format&fit=crop&q=80&w=600',
    tags: ['Clássico', 'Doce Quente'],
    isHighlight: true
  },
  {
    id: 'pudim',
    name: 'Pudim com Calda de Rapadura',
    description: 'Pudim de leite condensado super cremoso e sem furinhos, finalizado com uma calda artesanal de rapadura nordestina derretida com especiarias e raspas de limão cravo.',
    price: 18.00,
    category: 'sobremesas',
    image: 'https://images.unsplash.com/photo-1528975604071-b4dc52a2d18c?auto=format&fit=crop&q=80&w=600',
    tags: ['Artesanal']
  },
  {
    id: 'cocada',
    name: 'Cocada Cremosa de Tabuleiro',
    description: 'Cocada quente de colher feita com coco fresco ralado e leite condensado, gratinada no forno até formar uma crosta dourada irresistível. Servida com uma bola de sorvete de creme.',
    price: 20.00,
    category: 'sobremesas',
    image: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&q=80&w=600',
    tags: ['Quente com Gelado']
  },
  {
    id: 'bolinho',
    name: 'Bolinho de Macaxeira com Carne Seca',
    description: 'Porção com 6 unidades de bolinhos fritos dourados de mandioca com massa leve, recheados com carne seca desfiada e queijo coalho derretido. Acompanha geleia de pimenta defumada.',
    price: 32.00,
    category: 'porcoes',
    image: 'https://images.unsplash.com/photo-1608219990919-a868f97e87b7?auto=format&fit=crop&q=80&w=600',
    tags: ['Petisco', 'Croco', '6 Unidades']
  },
  {
    id: 'dadinhos',
    name: 'Dadinhos de Tapioca com Coalho',
    description: 'Porção com 8 dadinhos crocantes de tapioca granulada misturada com queijo coalho curado, fritos na temperatura ideal para ficarem sequinhos por fora e cremosos por dentro. Servidos com melaço de cana.',
    price: 28.00,
    category: 'porcoes',
    image: 'https://images.unsplash.com/photo-1546964124-0cce460f38ef?auto=format&fit=crop&q=80&w=600',
    tags: ['Vegetariano', 'Queridinho', '8 Unidades']
  },
  {
    id: 'suco_caja',
    name: 'Suco Natural de Cajá',
    description: 'Suco feito com polpa de cajá fresco, batido na hora com água mineral gelada ou leite. Super refrescante e rico em sabor.',
    price: 12.00,
    category: 'bebidas',
    image: 'https://images.unsplash.com/photo-1497534446932-c925b458314e?auto=format&fit=crop&q=80&w=600',
    tags: ['Fruta Típica', 'Sem Açúcar Opcional']
  },
  {
    id: 'caipirinha',
    name: 'Caipirinha Sertaneja',
    description: 'Cachaça artesanal de alta qualidade, limão taiti, açúcar de cana e um toque de gengibre macerado, servido em copo de barro com muito gelo.',
    price: 24.00,
    category: 'bebidas',
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&q=80&w=600',
    tags: ['Alcoólico', 'Autêntico']
  }
];

export const defaultReviews: Review[] = [
  {
    id: 'rev1',
    author: 'Mariana Vasconcellos',
    text: 'A comida é simplesmente deliciosa! O Baião de Dois estava perfeito, úmido e muito bem temperado. O queijo coalho grelhado dá um toque especialíssmo. O atendimento nos faz sentir em casa, com um acolhimento nota mil!',
    rating: 5,
    date: '2026-06-20',
    location: 'São Paulo, SP'
  },
  {
    id: 'rev2',
    author: 'José Augusto Silva',
    text: 'Excelente opção na região de Vila Prel. A carne de sol de Caicó é maravilhosa, macia e no ponto exato. O preço é super justo pela qualidade dos pratos e o tamanho das porções, que servem muito bem duas pessoas com fartura.',
    rating: 5,
    date: '2026-06-18',
    location: 'Taboão da Serra, SP'
  },
  {
    id: 'rev3',
    author: 'Renata Lacerda',
    text: 'A área verde do restaurante é um verdadeiro oásis em meio à correria de São Paulo! Um ambiente incrível, cheio de plantas e muito arejado. Comer o escondidinho ali ouvindo uma boa música nordestina é uma terapia.',
    rating: 4.8,
    date: '2026-06-12',
    location: 'Santo Amaro, SP'
  }
];

export const galleryImages = [
  {
    src: '/src/assets/images/opaio_hero_banner_1782400708182.jpg',
    title: 'Nossos Pratos Tradicionais',
    category: 'culinaria'
  },
  {
    src: '/src/assets/images/opaio_baiao_de_dois_1782400719225.jpg',
    title: 'O Famoso Baião de Dois',
    category: 'culinaria'
  },
  {
    src: '/src/assets/images/opaio_carne_de_sol_1782400751509.jpg',
    title: 'Carne de Sol Acebolada com Mandioca',
    category: 'culinaria'
  },
  {
    src: '/src/assets/images/ambient_cozy_indoor_1782402128797.jpg',
    title: 'Ambiente Interno Aconchegante',
    category: 'ambiente'
  },
  {
    src: '/src/assets/images/ambient_pergola_patio_1782402145177.jpg',
    title: 'Varanda Externa com Pergolado',
    category: 'ambiente'
  },
  {
    src: '/src/assets/images/ambient_turf_garden_1782402161783.jpg',
    title: 'Área Externa com Gramado',
    category: 'ambiente'
  },
  {
    src: '/src/assets/images/ambient_dining_tables_1782402176171.jpg',
    title: 'Nosso Salão Principal',
    category: 'ambiente'
  },
  {
    src: '/src/assets/images/ambient_umbrella_lane_1782402190662.jpg',
    title: 'Corredor das Mesas ao Ar Livre',
    category: 'ambiente'
  },
  {
    src: 'https://images.unsplash.com/photo-1546964124-0cce460f38ef?auto=format&fit=crop&q=80&w=800',
    title: 'Nossos Dadinhos de Tapioca',
    category: 'culinaria'
  },
  {
    src: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&q=80&w=800',
    title: 'Caipirinhas e Bebidas Regionais',
    category: 'bebidas'
  }
];
